import dht
import time
from machine import Pin, PWM, ADC

# Sensor DHT22 no GPIO 2
sensor_dht = dht.DHT22(Pin(2))

# LDR digital simulado (botão) no GPIO 5
sensor_ldr_digital = Pin(5, Pin.IN, Pin.PULL_UP)

# LDR analógico (real) no GPIO 34
ldr_analog = ADC(Pin(34))
ldr_analog.atten(ADC.ATTN_11DB)

# Sensor de chuva (botão) no GPIO 18
sensor_chuva = Pin(18, Pin.IN, Pin.PULL_UP)

# Servos no GPIO 4 (bomba) e GPIO 15 (cerca) 
servo1 = PWM(Pin(4), freq=50) # Simula a bomba d'agua O QUE FICA EM CIMA
servo2 = PWM(Pin(15), freq=50) # Simula a cerca  O QUE FICA EMBAIXO

# Funções para controlar servos
def control_servo1(angle):
    duty = int(40 + (angle / 180) * (115 - 40))
    servo1.duty(duty)
    print(f"Bomba: servo1 em {angle} graus")

def control_servo2(angle):
    duty = int(40 + (angle / 180) * (115 - 40))
    servo2.duty(duty)
    print(f"Cerca: servo2 em {angle} graus")

# Loop principal
while True:
    # Medir temperatura e umidade
    sensor_dht.measure()
    temp = sensor_dht.temperature()
    hum = sensor_dht.humidity()
    print(f"Temperatura: {temp}°C, Umidade: {hum}%")

    # Simular lógica de irrigação
    if sensor_chuva.value() == 0:
        print("Chuva detectada! Parando irrigação.")
        control_servo1(0)
    elif 30 < hum < 60:
        print("Umidade ideal. Irrigando!")
        control_servo1(90)
    elif hum > 80:
        print("Umidade muito alta. Não irrigar.")
        control_servo1(0)
    else:
        print("Umidade baixa. Irrigando!")
        control_servo1(90)

    # Controle de cerca com base no LDR digital
    if sensor_ldr_digital.value() == 1:
        print("Luz detectada. Levantar cerca.")
        control_servo2(90)
    else:
        print("Escuro. Abaixar cerca.")
        control_servo2(0)

    # Leitura analógica da luz (LDR real)
    luz = ldr_analog.read()
    print(f"Intensidade da luz (0-4095): {luz}")

    time.sleep(5)
